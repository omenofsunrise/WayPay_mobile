import 'package:flutter/material.dart';
import 'package:waypay_mobile/assets/resources.dart';
import 'package:waypay_styles/waypay_styles.dart';

enum CreditTab {
  all('Все договоры', SvgIcons.doc),
  favourite('Избранные', SvgIcons.favourite),
  debtors('Должники', SvgIcons.clockTwo),
  archived('В архиве', SvgIcons.archive);

  final String label;
  final String iconPath;

  const CreditTab(this.label, this.iconPath);
}

class CreditTabDropdown extends StatelessWidget {
  final CreditTab selectedTab;
  final void Function(CreditTab tab) onTabSelected;

  const CreditTabDropdown({
    super.key,
    required this.selectedTab,
    required this.onTabSelected,
  });

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<CreditTab>(
      color: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      icon: SizedBox(
        height: 40,
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Color(AppColors.borderColor)),
          ),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                // SvgPicture.asset(
                //   selectedTab.iconPath,
                //   width: 20,
                //   height: 20,
                //   color: Colors.black,
                // ),
                const SizedBox(width: 6),
                Text(
                  selectedTab.label,
                  style: AppStyle.manrope(
                    size: 14,
                    weight: FontWeight.w400,
                    color: Colors.black,
                  ),
                ),
                const SizedBox(width: 4),
                const Icon(Icons.arrow_drop_down, color: Colors.black),
              ],
            ),
          ),
        ),
      ),
      itemBuilder: (context) => [
        _buildTabItem(context, CreditTab.all),
        _buildTabItem(context, CreditTab.favourite),
        _buildTabItem(context, CreditTab.debtors),
        _buildTabItem(context, CreditTab.archived),
      ],
      onSelected: onTabSelected,
    );
  }

  PopupMenuItem<CreditTab> _buildTabItem(BuildContext context, CreditTab tab) {
    final isSelected = tab == selectedTab;
    return PopupMenuItem<CreditTab>(
      value: tab,
      child: InkWell(
        borderRadius: BorderRadius.circular(8),
        onTap: () {
          Navigator.pop(context);
          onTabSelected(tab);
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Row(
            children: [
              Icon(
                isSelected
                    ? Icons.radio_button_checked
                    : Icons.radio_button_off,
                color: isSelected ? Colors.teal : Colors.grey,
                size: 20,
              ),
              const SizedBox(width: 8),
              // SvgPicture.asset(
              //   tab.iconPath,
              //   width: 20,
              //   height: 20,
              //   color: Colors.black,
              // ),
              const SizedBox(width: 8),
              Text(
                tab.label,
                style: AppStyle.manrope(
                  size: 14,
                  weight: FontWeight.w400,
                  color: Colors.black,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
