import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:waypay/assets/resources.dart' show Images;
import 'package:waypay/core/di/dependency_injection.dart';
import 'package:waypay/core/network/token_storage.dart';
import 'package:waypay/core/network/dio_client.dart';
import 'package:waypay/core/storage/user_storage.dart';
import 'package:waypay/features/auth/data/data_sources/auth_remote_data_source.dart';
import 'package:waypay/features/auth/data/data_sources/auth_remote_data_source_impl.dart';
import 'package:waypay/core/theme/app_colors.dart';
import 'package:waypay/core/theme/app_style.dart';
import 'package:waypay/features/profile/data/models/employee.dart';
import 'package:waypay/routes/routes.dart';

class PinCodeScreen extends StatefulWidget {
  const PinCodeScreen({super.key});

  @override
  State<PinCodeScreen> createState() => _PinCodeScreenState();
}

class _PinCodeScreenState extends State<PinCodeScreen> {
  final List<String> _pin = [];
  final _tokenStorage = TokenStorage();

  String? _firstPin;
  String? _errorMessage;
  bool _isSecondStep = false;
  bool _isExistingUser = false;
  String? _savedPin;

  @override
  void initState() {
    super.initState();
    _checkExistingPin();
  }

  Future<void> _checkExistingPin() async {
    final savedPin = await _tokenStorage.getPinCode();
    if (savedPin != null) {
      setState(() {
        _isExistingUser = true;
        _savedPin = savedPin;
      });
    }
  }

  void _onKeyboardTap(String value) {
    if (value == 'back') {
      if (_pin.isNotEmpty) {
        setState(() => _pin.removeLast());
      }
    } else {
      if (_pin.length < 5) {
        setState(() => _pin.add(value));
        if (_pin.length == 5) {
          _onSubmit();
        }
      }
    }
  }

  Future<void> _updateUserRole() async {
    debugPrint("🔄 Обновление роли...");
    final authDataSource = getIt<AuthRemoteDataSource>();
    final userStorage = UserStorage();

    try {
      final info = await authDataSource.getAuthInfo();
      final employee = info['employee'] as Map<String, dynamic>?;

      if (employee == null) {
        debugPrint('⚠️ Нет данных о пользователе');
        return;
      }

      final roleStr = employee['role']?.toString() ?? '';
      final role = EmployeeRoleMapper.fromApi(roleStr);
      await userStorage.saveRole(role);

      final permissionsList = (employee['permissions'] as List?) ?? [];
      final permissions = permissionsList
          .map((p) => PermissionMapper.fromApi(p.toString()))
          .toList();
      await userStorage.savePermissions(permissions);

      debugPrint('✅ Роль обновлена: $role, права: $permissions');
    } catch (e) {
      debugPrint('❌ Ошибка при обновлении роли: $e');
    }
  }

  Future<void> _onSubmit() async {
    final pin = _pin.join();

    if (pin.length < 5) {
      setState(() {
        _errorMessage = 'Пин-код должен содержать минимум 5 цифры';
      });
      return;
    }

    if (_isExistingUser) {
      if (_savedPin == pin) {
        await _updateUserRole();
        if (!mounted) return;
        context.go(Routes.homeScreen.toPath);
      } else {
        setState(() {
          _errorMessage = 'Неверный пин-код';
          _pin.clear();
        });
      }
    } else {
      if (!_isSecondStep) {
        setState(() {
          _firstPin = pin;
          _pin.clear();
          _isSecondStep = true;
          _errorMessage = null;
        });
      } else {
        if (_firstPin == pin) {
          final dio = createDio(baseUrl: 'https://web.waypay.one:5001');
          final authDataSource = AuthRemoteDataSourceImpl(dio);

          try {
            await authDataSource.setupPin(pin);
            await _tokenStorage.savePinCode(pin);
            await _tokenStorage.setAuthenticated(true);
            await _updateUserRole();
            if (mounted) {
              context.go(Routes.homeScreen.toPath);
            }
          } catch (e) {
            setState(() {
              _errorMessage = e.toString();
            });
          }
        } else {
          setState(() {
            _errorMessage = 'Пин-коды не совпадают';
            _pin.clear();
            _isSecondStep = false;
            _firstPin = null;
          });
        }
      }
    }
  }

  Widget _buildPinDots() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(5, (index) {
        final filled = index < _pin.length;
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 6),
          width: 12,
          height: 12,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: filled ? const Color(AppColors.primary) : Colors.grey[400],
          ),
        );
      }),
    );
  }

  Widget _buildKey(String value) {
    return Padding(
      padding: const EdgeInsets.all(8),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () => _onKeyboardTap(value),
          child: Container(
            alignment: Alignment.center,
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              border: value != 'back'
                  ? Border.all(color: const Color(AppColors.primary))
                  : null,
              borderRadius: BorderRadius.circular(12),
            ),
            child: value == 'back'
                ? const Icon(
                    Icons.backspace_outlined,
                    color: Color(AppColors.primary),
                  )
                : Text(
                    value,
                    style: AppStyle.medium20.copyWith(
                      color: const Color(AppColors.primary),
                    ),
                  ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final keys = [
      ['1', '2', '3'],
      ['4', '5', '6'],
      ['7', '8', '9'],
      ['empty', '0', 'back'],
    ];

    String title;
    if (_isExistingUser) {
      title = 'Введите пин-код';
    } else if (_isSecondStep) {
      title = 'Повторите пин-код';
    } else {
      title = 'Придумайте пин-код';
    }

    return Scaffold(
      backgroundColor: Color(AppColors.background),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 32),
            Center(
              child: Image.asset(
                Images.backgroundLogo,
                height: 107,
                width: 107,
              ),
            ),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(title, style: AppStyle.medium20),
                  const SizedBox(height: 24),
                  _buildPinDots(),
                  if (_errorMessage != null) ...[
                    const SizedBox(height: 12),
                    Text(
                      _errorMessage!,
                      style: AppStyle.regular14.copyWith(
                        color: const Color(AppColors.red),
                      ),
                    ),
                  ],
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              child: Column(
                children: keys.map((row) {
                  return Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: row.map((key) {
                      if (key == 'empty') {
                        return Padding(
                          padding: const EdgeInsets.all(8),
                          child: const SizedBox(width: 60, height: 60),
                        );
                      }
                      return _buildKey(key);
                    }).toList(),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}
