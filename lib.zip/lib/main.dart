import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:waypay_mobile/core/di/dependency_injection.dart';
import 'package:waypay_mobile/features/admin_panel/presentation/cubit/company_cubit.dart';
import 'package:waypay_mobile/features/analytics/presentation/cubit/analytic_items_cubit.dart';
import 'package:waypay_mobile/features/analytics/presentation/cubit/debt_dynamic_cubit.dart';
import 'package:waypay_mobile/features/analytics/presentation/cubit/investment_dynamic_cubit.dart';
import 'package:waypay_mobile/features/analytics/presentation/cubit/sell_info_cubit.dart';
import 'package:waypay_mobile/features/auth/presentation/bloc/auth_cubit.dart';
import 'package:waypay_mobile/features/blog/presentation/bloc/blog_bloc.dart';
import 'package:waypay_mobile/features/blog/presentation/bloc/comment_bloc.dart';
import 'package:waypay_mobile/features/blog/presentation/cubit/profile_blog_cubit.dart';
import 'package:waypay_mobile/features/chat/presentation/bloc/chat_list/chat_list_bloc.dart';
import 'package:waypay_mobile/features/clients/presentation/bloc/clients/clients_bloc.dart';
import 'package:waypay_mobile/features/credit/presentation/bloc/credit_bloc.dart';
import 'package:waypay_mobile/features/credit/presentation/screens/create_credit/new_credit_creation_screen.dart';
import 'package:waypay_mobile/features/objectType/presentation/block/object_type_bloc.dart';
import 'package:waypay_mobile/features/credit/presentation/cubit/credit_creation_provider.dart';
import 'package:waypay_mobile/features/finance/presentation/bloc/budget/budget_expense_bloc.dart';
import 'package:waypay_mobile/features/finance/presentation/bloc/budget/budget_income_bloc.dart';
import 'package:waypay_mobile/features/investors/presentation/bloc/investors_bloc.dart';
import 'package:waypay_mobile/features/product/presentation/bloc/products_bloc.dart';
import 'package:waypay_mobile/features/profile/presentation/bloc/employees_bloc.dart';
import 'package:waypay_mobile/features/profile/presentation/cubit/credit_stats_cubit.dart';
import 'package:waypay_mobile/features/profile/presentation/cubit/payment_stats_cubit.dart';
import 'package:waypay_mobile/features/profile/presentation/cubit/profile_cubit.dart';
import 'package:waypay_mobile/features/todo/presentation/bloc/task_bloc.dart';
import 'package:waypay_mobile/features/network_error/screens/network_error_screen.dart';
import 'package:waypay_mobile/routes/app_router.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:waypay_styles/waypay_styles.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('ru_RU', null);
  await initDependencies();
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool? isOffline;
  late final StreamSubscription _subscription;

  @override
  void initState() {
    super.initState();
    _checkInitial();
    _subscription = Connectivity().onConnectivityChanged.listen((results) {
      final hasConnection = results.any((r) => r != ConnectivityResult.none);
      setState(() {
        isOffline = !hasConnection;
      });
    });
  }

  Future<void> _checkInitial() async {
    final results = await Connectivity().checkConnectivity();
    final hasConnection = results.any((r) => r != ConnectivityResult.none);
    setState(() {
      isOffline = !hasConnection;
    });
  }

  @override
  void dispose() {
    _subscription.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (isOffline == null) {
      return const MaterialApp(
        home: Scaffold(body: Center(child: CircularProgressIndicator())),
      );
    }

    final app = isOffline!
        ? const MaterialApp(home: NetworkErrorScreen())
        : MaterialApp.router(
            title: 'waypay_mobile',
            routerConfig: AppRouter.router,
            theme: ThemeData(
              colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
              useMaterial3: true,
              appBarTheme: const AppBarTheme(
                iconTheme: IconThemeData(color: Colors.white),
                backgroundColor: Color(AppColors.background),
              ),
            ),
          );

    return MultiBlocProvider(
      providers: [
        BlocProvider(create: (_) => getIt<AuthCubit>()),
        BlocProvider(create: (_) => getIt<InvestorsBloc>()),
        BlocProvider(create: (_) => getIt<ProductsBloc>()),
        BlocProvider(create: (_) => getIt<BudgetIncomeBloc>()),
        BlocProvider(create: (_) => getIt<BudgetExpenseBloc>()),
        BlocProvider(create: (_) => getIt<CreditBloc>()),
        BlocProvider(create: (_) => getIt<ProfileCubit>()),
        BlocProvider(create: (_) => getIt<EmployeesBloc>()),
        BlocProvider(create: (_) => getIt<CompanyCubit>()),
        BlocProvider(create: (_) => getIt<PaymentStatsCubit>()),
        BlocProvider(create: (_) => getIt<CreditStatsCubit>()),
        BlocProvider(create: (_) => getIt<AnalyticItemsCubit>()),
        BlocProvider(create: (_) => getIt<DebtDynamicCubit>()),
        BlocProvider(create: (_) => getIt<InvestmentDynamicCubit>()),
        BlocProvider(create: (_) => getIt<SellInfoCubit>()),
        BlocProvider(create: (_) => getIt<TaskBloc>()),
        BlocProvider(create: (_) => getIt<BlogBloc>()),
        BlocProvider(create: (_) => getIt<CommentBloc>()),
        BlocProvider(create: (_) => getIt<ProfileBlogCubit>()),
        BlocProvider(create: (_) => getIt<ChatListBloc>()),
        BlocProvider(create: (context) => ObjectTypeBloc()),
        BlocProvider(create: (_) => CreditCreationCubit()),
        BlocProvider<ClientsBloc>(
          create: (context) => getIt<ClientsBloc>(),
          child: NewCreditCreationScreen(),
        ),
      ],
      child: app,
    );
  }
}
