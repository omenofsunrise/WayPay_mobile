part of 'resources.dart';

class SvgIcons {
  SvgIcons._();

  static const String bell = 'assets/icons/bell.svg';
  static const String arrowBack = 'assets/icons/arrowBack.svg';

  static const String blog = 'assets/icons/blog.svg';
  static const String menuCalculator = 'assets/icons/menuCalculator.svg';
  static const String chat = 'assets/icons/chat.svg';
  static const String home = 'assets/icons/home.svg';
  static const String newCredit = 'assets/icons/newCredit.svg';
  static const String todo = 'assets/icons/todo.svg';

  static const String allCredits = 'assets/icons/all_credits.svg';
  static const String importantCredits = 'assets/icons/important_credits.svg';
  static const String debtCredits = 'assets/icons/debt_credits.svg';
  static const String inactiveCredits = 'assets/icons/inactive_credits.svg';

  static const String search = 'assets/icons/search.svg';
  static const String book = 'assets/icons/book.svg';
  static const String coolicon = 'assets/icons/coolicon.svg';
  static const String currencyDollar = 'assets/icons/currency-dollar.svg';
  static const String fileDigit = 'assets/icons/file-digit.svg';
  static const String moneybag = 'assets/icons/moneybag.svg';
  static const String notebook = 'assets/icons/notebook.svg';
  static const String users = 'assets/icons/users.svg';
  static const String vectorLogoBlack = 'assets/icons/vectorLogo_black.svg';
  static const String chartIcon = 'assets/icons/chart_icon.svg';
  static const String moneyIcon = 'assets/icons/money_icon.svg';
  static const String docIcon = 'assets/icons/doc_icon.svg';
  static const String clockIcon = 'assets/icons/clock_icon.svg';
  static const String logo = 'assets/icons/logo.svg';
  static const String todoLogo = 'assets/icons/todo.svg';
  static const String analyticLogo = 'assets/icons/analyticsLogo.svg';
  static const String chatLogo = 'assets/icons/chatLogo.svg';
  static const String blogLogo = 'assets/icons/blogLogo.svg';
  static const String calculator = 'assets/icons/calculator.svg';
  static const String cash = 'assets/icons/cash.svg';
  static const String companyAmount = 'assets/icons/company_amount.svg';
  static const String credits = 'assets/icons/credits.svg';
  static const String debtSelf = 'assets/icons/debt_self.svg';
  static const String debt = 'assets/icons/debt.svg';
  static const String delay = 'assets/icons/delay.svg';
  static const String investition = 'assets/icons/investition.svg';
  static const String investorAmount = 'assets/icons/investor_amount.svg';
  static const String investorCash = 'assets/icons/investor_cahs.svg';
  static const String investorIcon = 'assets/icons/investor_icon.svg';
  static const String investorPercent = 'assets/icons/investor_percent.svg';
  static const String shield_person = 'assets/icons/shield_person.svg';
}

class SvgIcon extends StatelessWidget {
  final String assetPath;
  final double? width;
  final double? height;
  final Color? color;

  const SvgIcon({
    super.key,
    required this.assetPath,
    this.width,
    this.height,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    return SvgPicture.asset(
      assetPath,
      width: width ?? 24,
      height: height ?? 24,
      colorFilter: color != null
          ? ColorFilter.mode(color!, BlendMode.srcIn)
          : null,
    );
  }
}
